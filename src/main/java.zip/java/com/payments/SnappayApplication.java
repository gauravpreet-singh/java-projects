package com.payments;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SnappayApplication {
    public static void main(String[] args) {
        SpringApplication.run(SnappayApplication.class, args);
    }
}